

import SwiftUI

@main
struct CWKTemplate24App: App {
    
    @StateObject private var weatherMapPlaceViewModel = WeatherMapPlaceViewModel()

    var body: some Scene {
        WindowGroup {
            NavBarView()
                .environmentObject(weatherMapPlaceViewModel)

            
        }
    }
}



import Foundation


struct AirDataModel: Codable {
    let list: [AirData]
}

struct AirData: Codable {
    let components: Components
}

struct Components: Codable {
    let so2: Double
    let no2: Double
    let pm10: Double
    let pm2_5: Double
    let o3: Double
    let co: Double
    let nh3: Double
    
}

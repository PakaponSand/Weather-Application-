import Foundation
import SwiftData

// A SwiftData model to store saved locations.
// The 'name' is marked as unique to prevent duplicate entries.
@Model
final class LocationData {
    @Attribute(.unique) var name: String
    var latitude: Double
    var longitude: Double
    var timestamp: Date

    init(name: String, latitude: Double, longitude: Double, timestamp: Date) {
        self.name = name
        self.latitude = latitude
        self.longitude = longitude
        self.timestamp = timestamp
    }
} 
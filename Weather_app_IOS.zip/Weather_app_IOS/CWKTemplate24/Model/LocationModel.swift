

import Foundation
import SwiftData


class LocationModel {
    var name: String
    var latitude: Double
    var longitude: Double
    
    // MARK:  list of attributes to manage locations

    init(name: String, latitude: Double, longitude: Double) {
        self.name = name
        self.latitude = latitude
        self.longitude = longitude
    }
}

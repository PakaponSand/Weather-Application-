

import Foundation
import CoreLocation



// A simple data model to represent a map annotation for a place of interest.
// It is identifiable to be used easily in SwiftUI lists and maps.
// It also conforms to Equatable so SwiftUI can compare instances to detect changes.
struct PlaceAnnotation: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D

    // Conformance to Equatable: two annotations are equal if their unique IDs are the same.
    static func == (lhs: PlaceAnnotation, rhs: PlaceAnnotation) -> Bool {
        lhs.id == rhs.id
    }
}

struct PlaceAnnotationDataModel {



}




import Foundation
import MapKit


class WeatherMapPlaceViewModel: ObservableObject {

   
    @Published var weatherDataModel: WeatherDataModel?
    @Published var newLocation = "London"
    @Published var airDataModel: AirDataModel?
    @Published var locationError: String?
    @Published var annotations: [PlaceAnnotation] = []
    


    init() {
        loadInitialData()
    }

    private func loadInitialData() {
        // Load weather data from london.json
        if let weatherURL = Bundle.main.url(forResource: "london", withExtension: "json"),
           let weatherData = try? Data(contentsOf: weatherURL),
           let weatherModel = try? JSONDecoder().decode(WeatherDataModel.self, from: weatherData) {
            self.weatherDataModel = weatherModel
            self.newLocation = "London"
        } else {
            print("Failed to load or decode london.json")
        }

        // Load air quality data from airQuality.json
        if let airURL = Bundle.main.url(forResource: "airQuality", withExtension: "json"),
           let airData = try? Data(contentsOf: airURL),
           let airModel = try? JSONDecoder().decode(AirDataModel.self, from: airData) {
            self.airDataModel = airModel
        } else {
            print("Failed to load or decode airQuality.json")
        }
    }

   
    func getCoordinatesForCity(_ city: String) async throws -> (Double, Double, String)? {
        guard let cityEncoded = city.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }
        let geoURLString = "https://api.openweathermap.org/geo/1.0/direct?q=\(cityEncoded)&limit=1&appid=74af342e01b3c0b717b1dffb1e10dd82"
        guard let geoURL = URL(string: geoURLString) else { return nil }
        let (geoData, _) = try await URLSession.shared.data(from: geoURL)
        if let geoResult = try? JSONDecoder().decode([GeocodingResult].self, from: geoData),
           let first = geoResult.first {
            return (first.lat, first.lon, first.name)
        }
        return nil
    }

  
    @MainActor
    func fetchWeatherData(lat: Double, lon: Double, locationName: String? = nil) async {
        let weatherURLString = "https://api.openweathermap.org/data/3.0/onecall?lat=\(lat)&lon=\(lon)&units=metric&appid=74af342e01b3c0b717b1dffb1e10dd82"
        guard let weatherURL = URL(string: weatherURLString) else { return }
        do {
            let (weatherData, _) = try await URLSession.shared.data(from: weatherURL)
            print(String(data: weatherData, encoding: .utf8) ?? "No data")
            let weatherModel = try JSONDecoder().decode(WeatherDataModel.self, from: weatherData)
            self.weatherDataModel = weatherModel
            if let name = locationName {
                self.newLocation = name
            }
            await fetchAirQuality(lat: lat, lon: lon)
        } catch {
            print("Weather fetch error:", error)
        }
    }

  
    @MainActor
    func fetchWeatherForLocation(_ city: String) async {
        if let (lat, lon, name) = try? await getCoordinatesForCity(city) {
            // Compare input and found name (case-insensitive, ignoring whitespace)
            let inputNormalized = city.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let foundNormalized = name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            if inputNormalized == foundNormalized {
                await fetchWeatherData(lat: lat, lon: lon, locationName: name)
                self.locationError = nil
            } else {
                self.locationError = "Location not found. Please enter a valid city name."
            }
        } else {
            self.locationError = "Location not found. Please enter a valid city name."
        }
    }

   
    struct GeocodingResult: Codable {
        let name: String
        let lat: Double
        let lon: Double
    }

    
    @MainActor
    func setAnnotations() async {
        // Ensure we have a valid location with coordinates before proceeding.
        guard let lat = weatherDataModel?.lat, let lon = weatherDataModel?.lon else {
            print("Coordinates are not available.")
            return
        }

        // Create a search request for "tourist attraction" near the location.
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = "tourist attraction"
        
        // Define a region centered on the location's coordinates to focus the search.
        let region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: lat, longitude: lon),
            span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        )
        request.region = region
        
        
        do {
            let search = MKLocalSearch(request: request)
            let response = try await search.start()
            
            // Map the search results to our custom PlaceAnnotation objects, taking the top 5.
            self.annotations = response.mapItems.prefix(5).map { item in
                PlaceAnnotation(
                    name: item.name ?? "Unknown Place",
                    coordinate: item.placemark.coordinate
                )
            }
        } catch {
            // If the search fails, print an error.
            print("Error during local search: \(error)")
        }
    }

    func fetchAirQuality(lat: Double, lon: Double) async {
        let urlString = "https://api.openweathermap.org/data/2.5/air_pollution?lat=\(lat)&lon=\(lon)&appid=74af342e01b3c0b717b1dffb1e10dd82"
        guard let url = URL(string: urlString) else { return }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let airModel = try JSONDecoder().decode(AirDataModel.self, from: data)
            await MainActor.run {
                self.airDataModel = airModel
            }
        } catch {
            print("Failed to fetch air quality:", error)
        }
    }
}

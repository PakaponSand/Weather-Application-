

import SwiftUI

struct CurrentWeatherView: View {


    @EnvironmentObject var weatherMapPlaceViewModel: WeatherMapPlaceViewModel


    @State private var showDetails = false
    @State private var locationInput = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        ZStack {
            //the background image for this view
            Image("sky")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .opacity(0.85)
            
            VStack(spacing: 20){
            Spacer().frame(height: 30)
                
                .padding(.top, 30)
                // show the data from jason reader
                if let weatherData = weatherMapPlaceViewModel.weatherDataModel?.current {
                    VStack(spacing: 16) {
                        Text(weatherMapPlaceViewModel.newLocation)
                            .font(.title)
                            .fontWeight(.bold)
                            .padding(.top, 16)
                        Text(
                            DateFormatterUtils.formattedDateTime(from: TimeInterval(weatherData.dt))
                                .replacingOccurrences(of: "AM", with: "am")
                                .replacingOccurrences(of: "PM", with: "pm")
                        )
                        .font(.title2)
                        .fontWeight(.semibold)
                        
                        HStack(alignment: .top, spacing: 32) {
                            VStack(alignment: .leading, spacing: 20) {
                                HStack(alignment: .top) {
                                    Image(systemName: "cloud.fill")
                                        .font(.title)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(weatherData.weather.first?.weatherDescription.rawValue.capitalized ?? "-")
                                            .font(.title2)
                                        
                                        if let feelsLike = weatherData.feelsLike as Double? {
                                            Text("Feels like: \(Int(feelsLike)) °C")
                                                .font(.title2)
                                        }
                                    }
                                }
                                HStack {
                                    Image(systemName: "thermometer")
                                        .font(.title2)
                                    Text("Temp: \(Int(weatherData.temp)) °C")
                                        .font(.title2)
                                }
                                HStack {
                                    Image(systemName: "wind")
                                        .font(.title2)
                                    Text("Wind: \(String(format: "%.0f", weatherData.windSpeed)) m/s")
                                        .font(.title2)
                                }
                                HStack {
                                    Image(systemName: "humidity")
                                        .font(.title2)
                                    Text("Humidity: \(weatherData.humidity) %")
                                        .font(.title2)
                                }
                                HStack {
                                    Image(systemName: "gauge")
                                        .font(.title2)
                                    Text("Pressure: \(weatherData.pressure) hPa")
                                        .font(.title2)
                                }
                            }
                            .font(.title2)
                            Spacer()
                        }
                        .padding(.vertical, 16)
                        .padding(.horizontal, 24)
                        .background(Color.white.opacity(0.5))
                        .cornerRadius(20)
                        .frame(maxWidth: .infinity, minHeight: 260)
                    }
                    .padding(.horizontal, 24)
                } else {
                    Text("Enter a location above to get weather information")
                        .foregroundColor(.secondary)
                        .padding(32)
                        .font(.title2)
                }

                if let air = weatherMapPlaceViewModel.airDataModel?.list.first?.components {
                    VStack(alignment: .center, spacing: 8) {
                        Text("Current Air Quality in \(weatherMapPlaceViewModel.newLocation)")
                            .font(.headline)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.top, 8)
                        HStack(spacing: 16) {
                            AirQualityBox(icon: "aqi.low", label: "SO₂", value: air.so2)
                            AirQualityBox(icon: "aqi.low", label: "NO₂", value: air.no2)
                            AirQualityBox(icon: "aqi.medium", label: "VOC", value: air.o3)
                            AirQualityBox(icon: "aqi.high", label: "PM", value: air.pm2_5)
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .frame(maxWidth: .infinity)
                }

                Spacer(minLength: 30)
            }
            .padding()
        }
        
    }
}

struct AirQualityBox: View {
    let icon: String
    let label: String
    let value: Double

    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .resizable()
                .scaledToFit()
                .frame(width: 36, height: 36)
                .foregroundColor(.black)
                .padding(.top, 4)
            Text(label)
                .font(.caption)
                .foregroundColor(.black)
            Text(String(format: "%.2f", value))
                .font(.headline)
                .foregroundColor(.black)
        }
        .frame(width: 70, height: 80)
        .background(Color.white.opacity(0.7))
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.vertical, 4)
        .padding(.horizontal, 2)
    }
}

#Preview {
    CurrentWeatherView()
        .environmentObject(WeatherMapPlaceViewModel())
}

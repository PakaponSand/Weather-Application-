

import SwiftUI

struct DailyWeatherView: View {
    @EnvironmentObject var weatherMapPlaceViewModel: WeatherMapPlaceViewModel

    var body: some View {
        Text("8-Day Forecast")
            .font(.title2).bold()
            

        ScrollView {
            VStack(spacing: 15) {
                if let daily = weatherMapPlaceViewModel.weatherDataModel?.daily {
                    ForEach(daily) { day in
                        DailyRowView(day: day)
                    }
                } else {
                    Text("No daily data available.")
                        .foregroundColor(.secondary)
                        .padding()
                }
            }
            .padding(.horizontal)
        }
    }
}

struct DailyRowView: View {
    let day: Daily

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: weatherIconName(for: day.weather.first?.main.rawValue ?? "Clear"))
                .font(.system(size: 28))
                .frame(width: 40, alignment: .center)

            VStack(alignment: .leading, spacing: 2) {
                Text(DateFormatterUtils.formattedDateWithWeekdayAndDay(from: TimeInterval(day.dt)))
                    .font(.headline)
                Text(day.weather.first?.weatherDescription.rawValue.capitalized ?? "")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            Text("\(Int(day.temp.min))°")
                .font(.headline)
                .fontWeight(.medium)
                .foregroundColor(.gray)

            ProgressView(value: progressValue, total: 1.0)
                .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                .frame(width: 80)

            Text("\(Int(day.temp.max))°")
                .font(.headline)
                .fontWeight(.medium)
                .foregroundColor(.black)
        }
        .padding()
        .background(Color.white.opacity(0.5))
        .cornerRadius(15)
        .frame(height: 60)
    }

    private var progressValue: Double {
        let range = day.temp.max - day.temp.min
        return range > 0 ? (day.temp.day - day.temp.min) / range : 0.5
    }

    func weatherIconName(for main: String) -> String {
        switch main.lowercased() {
        case "clear": return "sun.max.fill"
        case "clouds": return "cloud.fill"
        case "rain": return "cloud.rain.fill"
        case "snow": return "cloud.snow.fill"
        case "thunderstorm": return "cloud.bolt.rain.fill"
        case "drizzle": return "cloud.drizzle.fill"
        case "mist", "fog": return "cloud.fog.fill"
        default: return "cloud.fill"
        }
    }
}

#Preview {
    DailyWeatherView()
        .environmentObject(WeatherMapPlaceViewModel())
}

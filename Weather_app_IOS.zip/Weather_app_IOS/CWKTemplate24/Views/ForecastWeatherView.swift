
import SwiftUI

struct ForecastWeatherView: View {

    
        @EnvironmentObject var weatherMapPlaceViewModel: WeatherMapPlaceViewModel


    var body: some View {
        ZStack {
            Image("sky")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .opacity(0.85)
            VStack(spacing: 5){

                HourlyWeatherView()
                    .frame(height:250)
                DailyWeatherView()

            }
            .frame(height: 600)
            
        }
    }
}

#Preview {
    ForecastWeatherView()
        .environmentObject(WeatherMapPlaceViewModel())
}

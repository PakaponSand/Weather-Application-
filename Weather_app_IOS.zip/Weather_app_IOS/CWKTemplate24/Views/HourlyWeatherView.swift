
import SwiftUI

struct HourlyWeatherView: View {

    
    @EnvironmentObject var weatherMapPlaceViewModel: WeatherMapPlaceViewModel

    var body: some View {
        ScrollView {
            Text("Hourly Forecast Weather for \(weatherMapPlaceViewModel.newLocation)")
                .font(.title2).bold()
                .padding()

            if let hourly = weatherMapPlaceViewModel.weatherDataModel?.hourly {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 16) {
                        ForEach(hourly.prefix(24)) { forecast in // Show up to 24 hours
                            WeatherCardView(forecast: forecast)
                        }
                    }
                    .padding(.horizontal)
                }
            } else {
                Text("No hourly data available.")
                    .foregroundColor(.secondary)
                    .padding()
            }
        }
    }
}

struct WeatherCardView: View {
    let forecast: Current
    
    var body: some View {
        VStack(spacing:5) {
            // Time with better formatting
            Text(DateFormatterUtils.formattedDateWithDay(from: TimeInterval(forecast.dt)))
                .font(.title3)
                .fontWeight(.medium)
                .foregroundColor(.white)
            
            // Weather icon (using SF Symbols as placeholder)
            Image(systemName: weatherIconName(for: forecast.weather.first?.main.rawValue ?? "Clear"))
                .font(.system(size: 30))
                .foregroundColor(.white)
            
            // Temperature
            Text("\(Int(round(forecast.temp)))°C")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            // Weather description
            Text(forecast.weather.first?.weatherDescription.rawValue.capitalized ?? "")
                .font(.caption)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
        }
        .padding()
        .frame(width: 130, height: 160)
        .background(Color.blue.opacity(0.5))
        .cornerRadius(12)
    }

    // Helper to map weather main to SF Symbol
    func weatherIconName(for main: String) -> String {
        switch main.lowercased() {
        case "clear": return "sun.max.fill"
        case "clouds": return "cloud.fill"
        case "rain": return "cloud.rain.fill"
        case "snow": return "cloud.snow.fill"
        case "thunderstorm": return "cloud.bolt.rain.fill"
        case "drizzle": return "cloud.drizzle.fill"
        case "mist", "fog": return "cloud.fog.fill"
        default: return "cloud.fill"
        }
    }
}

#Preview {
    HourlyWeatherView()
        .environmentObject(WeatherMapPlaceViewModel())
}

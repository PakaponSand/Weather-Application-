

import SwiftUI
import MapKit

struct MapView: View {
    @EnvironmentObject var weatherMapPlaceViewModel: WeatherMapPlaceViewModel
    @State private var position: MapCameraPosition = .automatic

    var body: some View {
        ZStack {
            // Background image that covers the entire screen safely.
            Image("sky")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)

            VStack {
                mapSection
                attractionsListSection
            }
            .padding(.top, 100)
        }
        .onAppear {
            // When the view appears, fetch the tourist attractions.
            Task {
                await weatherMapPlaceViewModel.setAnnotations()
            }
        }
        .onChange(of: weatherMapPlaceViewModel.annotations) {
            // When annotations are loaded, focus the map on them.
            if let firstCoordinate = weatherMapPlaceViewModel.annotations.first?.coordinate {
                position = .camera(MapCamera(centerCoordinate: firstCoordinate, distance: 10000))
            }
        }
    }

    private var mapSection: some View {
    
        Map(position: $position) {
            // Loop through the annotations from the ViewModel and display them.
            ForEach(weatherMapPlaceViewModel.annotations) { place in
                Annotation(place.name, coordinate: place.coordinate) {
                    // Custom view for each map pin.
                    ZStack {
                        Circle()
                            .fill(Color.red.opacity(0.8))
                            .frame(width: 32, height: 32)
                        
                        Image(systemName: "mappin.and.ellipse")
                            .symbolEffect(.pulse)
                            .foregroundColor(.white)
                            .padding(5)
                    }
                }
            }
        }
        .frame(height: 300)
        .cornerRadius(15)
        .padding(.horizontal)
        .padding(.top)
    }

    private var attractionsListSection: some View {
        ZStack {
            VStack {
                // The title, positioned between the map and the list.
                Text("Top 5 Tourist Attractions in \(weatherMapPlaceViewModel.newLocation)")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding()
                    .foregroundColor(.white)
                    .shadow(radius: 5) // Increased shadow for better readability

                // The scrollable list of attraction names.
                ScrollView {
                    ForEach(weatherMapPlaceViewModel.annotations) { place in
                        HStack {
                            Image(systemName: "mappin.circle.fill")
                                .foregroundColor(.red)
                            Text(place.name)
                                .font(.headline)
                                .foregroundColor(.white)
                            Spacer()
                        }
                        .padding()
                        .background(.black.opacity(0.5)) 
                        .cornerRadius(10)
                        .padding(.horizontal)
                        .padding(.bottom, 5)
                    }
                }
            }
        }
    }
}

#Preview {
    MapView()
        .environmentObject(WeatherMapPlaceViewModel())
}

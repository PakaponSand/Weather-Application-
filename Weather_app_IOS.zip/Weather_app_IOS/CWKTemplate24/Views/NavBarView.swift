

import SwiftUI

struct NavBarView: View {



    @EnvironmentObject var weatherMapPlaceViewModel: WeatherMapPlaceViewModel
    @State private var selectedLocation: LocationModel? = nil
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var locationInput: String = ""
    @State private var isFetchingLocation = false



    init() {
        // Customize TabView appearance
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        
        // Background styling
        appearance.backgroundColor = UIColor.systemBackground
        
        // Normal state styling
        appearance.stackedLayoutAppearance.normal.iconColor = UIColor.systemGray
        appearance.stackedLayoutAppearance.normal.titleTextAttributes = [
            .foregroundColor: UIColor.systemGray,
            .font: UIFont.systemFont(ofSize: 12, weight: .medium)
        ]
        
        // Selected state styling
        appearance.stackedLayoutAppearance.selected.iconColor = UIColor.systemBlue
        appearance.stackedLayoutAppearance.selected.titleTextAttributes = [
            .foregroundColor: UIColor.systemBlue,
            .font: UIFont.systemFont(ofSize: 12, weight: .semibold)
        ]
        
        // Apply the appearance
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
        
        // Additional tab bar properties
        UITabBar.appearance().tintColor = UIColor.systemBlue
        UITabBar.appearance().unselectedItemTintColor = UIColor.systemGray
    }

    var body: some View {
        VStack(spacing: 0) {
            // Location input section
            VStack(spacing: 10) {
                HStack {
                    Text("Change Location:")
                        .font(.headline)
                    ZStack(alignment: .trailing) {
                        TextField("Enter New Location", text: $locationInput)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.words)
                            .disableAutocorrection(true)
                            .onSubmit {
                                let trimmed = locationInput.trimmingCharacters(in: .whitespacesAndNewlines)
                                if !trimmed.isEmpty {
                                    isFetchingLocation = true
                                    Task {
                                        await weatherMapPlaceViewModel.fetchWeatherForLocation(trimmed)
                                        isFetchingLocation = false
                                        if weatherMapPlaceViewModel.locationError == nil {
                                            locationInput = ""
                                        }
                                        
                                    }
                                }
                            }
                            .padding(8)
                            .background(Color.white.opacity(0.5))
                        if isFetchingLocation {
                            ProgressView()
                                .padding(.trailing, 8)
                        }
                    }
                }
                .padding(.horizontal)
            }
            .padding(.top, 8)
            .background(
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .frame(height: 60)
                    .clipped()
            )

            // Your TabView with all the tabs
            TabView {
                CurrentWeatherView()
                    .tabItem { Label("Now", systemImage: "sun.max.fill") }
                ForecastWeatherView()
                    .tabItem { Label("5-Day Weather", systemImage: "calendar") }
                MapView()
                    .tabItem { Label("Place Map", systemImage: "map") }
            }
            .onAppear {
                // MARK:  Write code to manage what happens when this view appears
            }
            .onReceive(weatherMapPlaceViewModel.$locationError) { error in
                if let error = error {
                    alertMessage = error
                    showAlert = true
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Error"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
        
    }
}

#Preview {
    NavBarView()
        .environmentObject(WeatherMapPlaceViewModel())
}



import SwiftUI

struct VisitedPlacesView: View {


    
    var body: some View {
        VStack{
            
        }
        .frame(height: 600)
    }
}

#Preview {
    VisitedPlacesView()
}
